<template>
    <header>
        <h1>TODO清单</h1>
    </header>
</template>


<style lang="less" scoped>
@import "../assets/styles/global.less";

    h1{
        text-align: center;
        color: @mainclr;
        font-size: 3rem
    }
</style>
