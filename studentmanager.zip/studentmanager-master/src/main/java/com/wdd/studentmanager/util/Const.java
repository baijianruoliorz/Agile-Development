package com.wdd.studentmanager.util;

public class Const {
    public static final String CODE = "code";
    public static final String ADMIN = "admin";
    public static final String STUDENT = "student";
    public static final String TEACHER = "teacher";
    public static final String USERTYPE = "usertype";

}
