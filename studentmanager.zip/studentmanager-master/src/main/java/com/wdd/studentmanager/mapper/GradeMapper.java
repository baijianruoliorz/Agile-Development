package com.wdd.studentmanager.mapper;

/**
 * @Classname GradeMapper
 * @Description None
 * @Date 2019/6/24 20:09
 * @Created by WDD
 */
public interface GradeMapper {
}
